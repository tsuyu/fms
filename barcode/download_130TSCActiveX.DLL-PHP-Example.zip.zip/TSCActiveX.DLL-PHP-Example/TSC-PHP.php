  
<html>
   <head>
       <title>Example</title>
   </head>
   <body>

       <?php 
              echo "This is a TSCActiveX.Dll test in PHP 5.0.";
              $TSCObj = new COM ("TSCActiveX.TSCLIB");
              $TSCObj->ActiveXopenport ("TSC TTP-245 Plus");
              //$TSCObj->ActiveXdownloadpcx("G:\Program Files\Apache Software Foundation\Apache2.2\htdocs\UL.PCX","UL.PCX");
              $TSCObj->ActiveXsetup("101.6", "63.5", "5", "8", "0", "0", "0");
              $TSCObj->ActiveXclearbuffer();
              //$TSCObj->ActiveXsendcommand("PUTPCX 10,200,\"UL.PCX\"");
              $TSCObj->ActiveXwindowsfont(400, 200, 48, 0, 3, 1, "arial", "DEG 0");
              $TSCObj->ActiveXwindowsfont(400, 200, 48, 90, 3, 1, "arial", "DEG 90");
              $TSCObj->ActiveXwindowsfont(400, 200, 48, 180, 3, 1, "arial", "DEG 180");
              $TSCObj->ActiveXwindowsfont(400, 200, 48, 270, 3, 1, "arial", "DEG 270");
              $TSCObj->ActiveXbarcode("100", "40", "128", "50", "1", "0", "2", "2", "123456789");
              $TSCObj->ActiveXprintlabel("1","1");
              $TSCObj->ActiveXcloseport();

       ?>
   </body>
</html> 



